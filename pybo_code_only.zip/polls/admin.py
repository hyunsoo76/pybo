from django.contrib import admin
from .models import Question, Chioce


admin.site.register(Question)
admin.site.register(Chioce)