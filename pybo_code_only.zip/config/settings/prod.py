from .base import *

ALLOWED_HOSTS = ['3.37.211.248']
STATIC_ROOT = BASE_DIR / 'static/'
STATICFILES_DIRS = []
DEBUG = True