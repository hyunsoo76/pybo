from django.apps import AppConfig


class PaystubConfig(AppConfig):
    name = 'paystub'
