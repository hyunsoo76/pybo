from django.apps import AppConfig


class EasConfig(AppConfig):
    name = 'eas'
